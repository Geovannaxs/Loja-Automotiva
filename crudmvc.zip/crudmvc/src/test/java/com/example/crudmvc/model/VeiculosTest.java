package com.example.crudmvc.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VeiculosTest {

    @Test
    void deveCriarVeiculosComConstrutor() {
        Veiculos veiculos= new Veiculos("Audi", "R8", 590.000 , 2026);

        assertEquals("Audi", veiculos.getMarca());
        assertEquals("R8", veiculos.getModelo());
        assertEquals(590.000, veiculos.getPreco());
        assertEquals(2026, veiculos.getAno());
    }

    @Test
    void deveAlterarDadosDoAluno() {
        Veiculos veiculos = new Veiculos();

        veiculos.setId(1L);
        veiculos.setMarca("Audi");
        veiculos.setModelo("R8");
        veiculos.setPreco(590.000);
        veiculos.setAno(2026);

        assertEquals(1L, veiculos.getId());
        assertEquals("Audi", veiculos.getMarca());
        assertEquals("R8", veiculos.getModelo());
        assertEquals(590.000, veiculos.getPreco());
        assertEquals(2026, veiculos.getAno());
    }
}